﻿using System;

public class MinimumBalanceException : Exception
{
    public MinimumBalanceException(string message) : base(message) { }
}
